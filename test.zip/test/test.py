# -*- coding: utf-8 -*-
import os
import sys
import time
import random

import cv2
import torch
import torch.nn as nn
import numpy as np

from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QApplication, QFileDialog, QGraphicsScene
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt, QThread, Signal


BASE_DIR = os.path.dirname(os.path.abspath(__file__))

FAKEFORMER_DIR = "F:/FakeFormer-main"
CONFIG_PATH = "configs/spatial/vit_sbi_base.yaml"
UI_PATH = os.path.join(BASE_DIR, "test.ui")

os.chdir(FAKEFORMER_DIR)

if FAKEFORMER_DIR not in sys.path:
    sys.path.append(FAKEFORMER_DIR)

from package_utils.transform import (
    final_transform,
    get_center_scale,
    get_affine_transform,
)
from configs.get_config import load_config
from models import *
from package_utils.image_utils import load_image


class FakeFormerDetector:
    def __init__(self):
        self.cfg = load_config(CONFIG_PATH)

        seed = self.cfg.SEED
        random.seed(seed)
        torch.manual_seed(seed)
        np.random.seed(seed)

        self.use_cuda = torch.cuda.is_available()

        if self.use_cuda:
            torch.cuda.manual_seed(seed)

        self.device_count = torch.cuda.device_count()

        self.model = build_model(self.cfg.MODEL, MODELS).to(torch.float64)
        self.model = load_pretrained(self.model, self.cfg.TEST.pretrained)

        if self.use_cuda:
            if self.device_count >= 1:
                self.model = nn.DataParallel(
                    self.model,
                    device_ids=self.cfg.TEST.gpus
                ).cuda()
            else:
                self.model = self.model.cuda()

        self.model.eval()

        self.aspect_ratio = (
            self.cfg.DATASET.IMAGE_SIZE[1] * 1.0 /
            self.cfg.DATASET.IMAGE_SIZE[0]
        )

        self.pixel_std = 200
        self.rot = 0
        self.transforms = final_transform(self.cfg.DATASET)

    def predict(self, image_path):
        img = load_image(image_path)
        img = cv2.resize(img, (317, 317))
        img = img[18:(317 - 18), 18:(317 - 18), :]

        c, s = get_center_scale(
            img.shape[:2],
            self.aspect_ratio,
            self.pixel_std
        )

        trans = get_affine_transform(
            c,
            s,
            self.rot,
            self.cfg.DATASET.IMAGE_SIZE
        )

        input_img = cv2.warpAffine(
            img,
            trans,
            (
                int(self.cfg.DATASET.IMAGE_SIZE[0]),
                int(self.cfg.DATASET.IMAGE_SIZE[1])
            ),
            flags=cv2.INTER_LINEAR,
        )

        with torch.no_grad():
            st = time.time()

            img_trans = self.transforms(input_img / 255).to(torch.float64)
            img_trans = torch.unsqueeze(img_trans, 0)

            if self.use_cuda:
                img_trans = img_trans.cuda(non_blocking=True)

            outputs = self.model(img_trans)

            cls_outputs = outputs[0]["cls"].sigmoid()
            label_pred = cls_outputs.cpu().numpy()

            score = label_pred[0][-1]
            label = "Fake" if score > self.cfg.TEST.threshold else "Real"

            infer_time = time.time() - st

        predict_line = f"{label} --- {score}"
        infer_time_line = f"Inferencing time --- {infer_time}"

        return predict_line, infer_time_line


class LoadModelThread(QThread):
    finished = Signal(object)
    failed = Signal(str)

    def run(self):
        try:
            detector = FakeFormerDetector()
            self.finished.emit(detector)
        except Exception as e:
            self.failed.emit(str(e))


class DetectThread(QThread):
    finished = Signal(str, str, str)
    failed = Signal(str)

    def __init__(self, detector, image_path):
        super().__init__()
        self.detector = detector
        self.image_path = image_path

    def run(self):
        try:
            predict_line, infer_time = self.detector.predict(self.image_path)
            self.finished.emit(self.image_path, predict_line, infer_time)
        except Exception as e:
            self.failed.emit(str(e))


class HBMainWindow:
    def __init__(self):
        loader = QUiLoader()
        self.ui = loader.load(UI_PATH)

        self.scene = QGraphicsScene()
        self.ui.graphicsView.setScene(self.scene)

        self.detector = None
        self.load_thread = None
        self.detect_thread = None

        self.ui.StartButton.setEnabled(False)
        self.ui.ROF.setText("模型載入中，請稍候...")

        self.ui.StartButton.clicked.connect(self.start_test)

        self.load_model()

    def load_model(self):
        self.load_thread = LoadModelThread()
        self.load_thread.finished.connect(self.model_loaded)
        self.load_thread.failed.connect(self.model_load_failed)
        self.load_thread.start()

    def model_loaded(self, detector):
        self.detector = detector
        self.ui.StartButton.setEnabled(True)
        self.ui.ROF.setText("模型載入完成，可以開始偵測")

    def model_load_failed(self, error):
        self.ui.StartButton.setEnabled(False)
        self.ui.ROF.setText("模型載入失敗：\n" + error)

    def start_test(self):
        if self.detector is None:
            self.ui.ROF.setText("模型尚未載入完成")
            return

        image_path, _ = QFileDialog.getOpenFileName(
            self.ui,
            "選擇圖片",
            "",
            "Image Files (*.jpg *.jpeg *.png *.bmp)"
        )

        if not image_path:
            return

        self.ui.StartButton.setEnabled(False)
        self.ui.ROF.setText("模型偵測中，請稍候...")

        self.detect_thread = DetectThread(self.detector, image_path)
        self.detect_thread.finished.connect(self.handle_result)
        self.detect_thread.failed.connect(self.detect_failed)
        self.detect_thread.start()

    def handle_result(self, image_path, predict_line, infer_time):
        self.ui.StartButton.setEnabled(True)

        if "Fake ---" in predict_line or "Real ---" in predict_line:
            self.show_image(image_path)
            self.ui.ROF.setText(f"{predict_line}\n{infer_time}")
        else:
            self.ui.ROF.setText("無法判斷結果")

        self.detect_thread = None

    def detect_failed(self, error):
        self.ui.StartButton.setEnabled(True)
        self.ui.ROF.setText("偵測失敗：\n" + error)
        self.detect_thread = None

    def show_image(self, image_path):
        self.scene.clear()

        pixmap = QPixmap(image_path)
        self.scene.addPixmap(pixmap)

        self.ui.graphicsView.setScene(self.scene)
        self.ui.graphicsView.fitInView(
            self.scene.itemsBoundingRect(),
            Qt.KeepAspectRatio
        )


if __name__ == "__main__":
    app = QApplication([])
    hb_window = HBMainWindow()
    hb_window.ui.show()
    app.exec()